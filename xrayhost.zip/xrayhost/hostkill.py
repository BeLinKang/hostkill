#!/usr/bin/python
# -*- coding: UTF-8 -*-
print('''


              _______  _______ _________   _       _________ _        _        _______  _______ 
    |\     /|(  ___  )(  ____ \\__   __/  | \    /\\__   __/( \      ( \      (  ____ \(  ____ )
    | )   ( || (   ) || (    \/   ) (     |  \  / /   ) (   | (      | (      | (    \/| (    )|
    | (___) || |   | || (_____    | |     |  (_/ /    | |   | |      | |      | (__    | (____)|
    |  ___  || |   | |(_____  )   | |     |   _ (     | |   | |      | |      |  __)   |     __)
    | (   ) || |   | |      ) |   | |     |  ( \ \    | |   | |      | |      | (      | (\ (   
    | )   ( || (___) |/\____) |   | |     |  /  \ \___) (___| (____/\| (____/\| (____/\| ) \ \__
    |/     \|(_______)\_______)   )_(_____|_/    \/\_______/(_______/(_______/(_______/|/   \__/
                                    (_____)                                                     


---powered by L0ading
''')
from os import O_APPEND


#filename = input ("Please enter your file name: ")
alldomainlist = []
with open ("domains.txt") as file:
    for line in file.readlines():
        alldomainlist.append(line.strip().split(" "))
#print(alldomainlist)

j = ['172','192','10']
with open("hosts.txt","w")as f:

    for i in range(0, len(alldomainlist)):
        every_domain_str  = alldomainlist[i][0]
        str_list = every_domain_str.split(",")
        if str_list[1] != '':
            ip_start = str_list[1].split(".")
            if ip_start[0] in j:
                print(str_list[0]+"内网ip:"+str_list[1])
                f.write(str_list[0] + "\n")

with open("ips.txt","w")as g:
    for i in range(0, len(alldomainlist)):
        every_domain_str  = alldomainlist[i][0]
        str_list = every_domain_str.split(",")
        if str_list[1] != '':
            ip_start = str_list[1].split(".")
            if ip_start[0] not in j:
                print("所有ip为" + str_list[1])
                g.write(str_list[1] + "\n")